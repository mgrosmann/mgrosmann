<div id="Description"><h2>Abris:</h2>
  Description des abris
</div>
<div id="Produits">
   les abris

</div>