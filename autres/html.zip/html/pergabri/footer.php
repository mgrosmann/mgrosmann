  <div id="Footer"><h2>Pied de page</h2>


                <h2>Nos réseaux sociaux:</h2>
                <img src="image/twitter.png" width="50" height="50"/>
                <a href="https://twitter.com/home" class="bFoot">Twitter</a>
                <img src="image/facebook.png" width="50" height="50"/>
                <a href="https://www.facebook.com/" class="bFoot">Facebook</a>
                <img src="image/Instagram.png" width="50" height="50"/>
                <a href="https://www.instagram.com/" class="bFoot">Instagram</a>
                <h2>Pour plus d'informations sur le groupe Pergabri:</h2>
                <a href="mentions.html" class="bFoot">Mentions</a>

            </div>