<div id="Logo"><img src="image/logo_pergabri.png" width="100" height="100"/></div>
<table id="Menu">
    <tr>
        <td><a href="index.php?page=accueil" class="bFoot">Accueil</a></td>
        <td><a href="index.php?page=pergolas" class="bFoot">Pergolas</a></td>
        <td><a href="index.php?page=abris" class="bFoot">Abris</a></td>
        <td><a href="contact.html" class="bFoot">Contact</a></td>
        <td><a href="mentions.html" class="bFoot">Mentions</a></td>

    </tr>
</table>