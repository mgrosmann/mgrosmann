<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        #character {
            position: absolute;
            top: 0;
            left: 0;
        }
    </style>
    <title>Personnage Déplaçable (JavaScript)</title>
</head>
<body>
    <h1>Personnage Déplaçable (JavaScript)</h1>

    <!-- Remplacez le chemin "chemin/vers/votre/image.png" par le chemin réel de votre image -->
    <img id="character" src="image/z.jpg"alt="Personnage">

    <script>
        // Position initiale du personnage
        let x = 0;
        let y = 0;

        // Référence vers l'élément du personnage
        const character = document.getElementById('character');

        // Fonction pour mettre à jour la position du personnage
        function updatePosition() {
            character.style.top = y + 'px';
            character.style.left = x + 'px';
        }

        // Gestion des événements de déplacement
        window.addEventListener('keydown', (event) => {
            switch (event.key) {
                case 'ArrowUp':
                    y -= 30;
                    break;
                case 'ArrowDown':
                    y += 30;
                    break;
                case 'ArrowLeft':
                    x -= 30;
                    break;
                case 'ArrowRight':
                    x += 30;
                    break;
            }
            updatePosition();
        });
    </script>
</body>
</html>
