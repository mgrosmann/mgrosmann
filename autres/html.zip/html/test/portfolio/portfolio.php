<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="style.css"/>
    <link rel="shortcut icon" href="image/lego.webp">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portfolio</title>
</head>
<body>
    <h1>Portfolio</h1>

    <table id="Menu">
        <tr>
            <td><a href="portfolio.php?page=LOTR" class="bFoot">Icone Personnage Lego</a></td>
            <td><a href="portfolio.php?page=test1" class="bFoot">Test1</a></td>
            <td><a href="portfolio.php?page=test2" class="bFoot">Test2</a></td>
            <td><a href="Test3.html" class="bFoot">Test 3</a></td>
            <td><a href="test4.html" class="bFoot">test 4</a></td>
        </tr>
    </table>

    <!-- Incluez dynamiquement le contenu en fonction de la valeur de 'page' -->
    <?php
    // Vérifier si 'page' est défini dans l'URL et assigner à la variable $page
    $page = isset($_GET['page']) ? $_GET['page'] : null;

    // Utilisez une structure switch pour déterminer quelle page inclure
    switch ($page) {
        case 'Test0':
            include 'LOTR.php';
            break;
        case 'test1':
            include 'Test1.php';
            break;
        case 'test2':
            include 'Test2.php';
            break;
        case 'Marvel':
            include 'Marvel.php';
            break;
        case 'LOTR':
            include 'LOTR.php';
            break;
        case 'Hobbit':
            include 'Hobbit.php';
            break;
        case 'LSWCS':
            include 'LSWCS.php';
            break;
        case 'POTC':
            include 'POTC.php';
            break;
        case 'Harry_Potter':
            include 'Harry_Potter.php';
            break;
        case 'DCComics':
            include 'DCComics.php';
            break;
        case 'LegoMovie':
            include 'LegoMovie.php';
            break;
        case 'Clone_Wars':
            include 'Clone_Wars.php';
            break;
        case 'LBM2':
            include 'LBM2.php';
            break;
        default:
            echo "<p>Page non trouvée.</p>"; // Ajout d'un message d'erreur par défaut.
            break;
    }
    ?>

    <!-- Ajoutez d'autres éléments HTML en fonction de votre contenu -->
</body>
</html>
