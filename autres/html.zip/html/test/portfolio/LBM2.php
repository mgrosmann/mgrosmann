<!-- test0.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test 0</title>
    <style>
        figure {
            display: inline-block;
            margin: 0;
        }

        figcaption {
            text-align: center;
        }
    </style>
</head>
<body>

<table id="Menu">
    <tr>
        <td><a href="portfolio.php?page=LOTR" class="bFoot">LOTR</a></td>
        <td><a href="portfolio.php?page=Hobbit" class="bFoot">Hobbit</a></td>
        <td><a href="portfolio.php?page=LSWCS" class="bFoot">LSWCS</a></td>
        <td><a href="portfolio.php?page=POTC" class="bFoot">POTC</a></td>
        <td><a href="portfolio.php?page=Marvel" class="bFoot">Marvel</a></td>
        <td><a href="portfolio.php?page=Harry_Potter" class="bFoot">Harry Potter</a></td>
        <td><a href="portfolio.php?page=DCComics" class="bFoot">DC Comics</a></td>
        <td><a href="portfolio.php?page=LegoMovie" class="bFoot">Lego Movie</a></td>
        <td><a href="portfolio.php?page=Clone_Wars" class="bFoot">Clone_Wars</a></td>
        <td><a href="portfolio.php?page=LBM2" class="bFoot">LBM2</a></td>


    </tr>
</table>

<!-- Utilisation de la balise figure pour regrouper l'image et son commentaire -->
<figure style="float: left; margin-right: 20px;">
    <img src="image/Alfred_LBM2.webp" alt="Description de l'image A-Bomb">
    <figcaption> Alfred (LBM2)</figcaption>
</figure>
<figure style="float: left;">
    <img src="image/Aquaman.webp" alt="Description de l'image Abomination">
    <figcaption> Aquaman </figcaption>
</figure>
<figure style="float: left;">
    <img src="image/Bane_LBM2.webp" alt="Description de l'image absorbing_man">
    <figcaption> Bane </figcaption>
</figure>
<figure style="float: left;">
    <img src="image/Batgirl.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Batgirl </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Batman_(darkest_knight).webp" alt="Description de l'image Agent_Coulson">
    <figcaption> Batman (darkest knight) </figcaption>
</figure>
    <figure style="float: left;">
    <img src="image/Batman_LBM3.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Batman(LBM3) </figcaption>
    </figure>
    <figure style="float: left;">
    <img src="image/Batman_LBM2.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Batman(LBM2) </figcaption>
    </figure>
 <figure style="float: left;">
    <img src="image/Black_Canary.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Black Canary </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Black_Manta_icon.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Black Manta </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Brainiac_icon.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Brainiac </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Captain_Boomerang.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Captain Boomerang </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/CatwomanLBM2.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Catwoman </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Clark_Kent_icon.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Clark Kent </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Clayface_icon.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Clayface </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Clown_Goon_icon.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Clown Goon </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Cyborg.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Cyborg </figcaption>
    </figure>



</body>
</html>
