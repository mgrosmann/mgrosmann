<!-- test0.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test 0</title>
    <style>
        figure {
            display: inline-block;
            margin: 0;
        }

        figcaption {
            text-align: center;
        }
    </style>
</head>
<body>

<table id="Menu">
    <tr>
        <td><a href="portfolio.php?page=LOTR" class="bFoot">LOTR</a></td>
        <td><a href="portfolio.php?page=Hobbit" class="bFoot">Hobbit</a></td>
        <td><a href="portfolio.php?page=LSWCS" class="bFoot">LSWCS</a></td>
        <td><a href="portfolio.php?page=POTC" class="bFoot">POTC</a></td>
        <td><a href="portfolio.php?page=Marvel" class="bFoot">Marvel</a></td>
        <td><a href="portfolio.php?page=Harry_Potter" class="bFoot">Harry Potter</a></td>
        <td><a href="portfolio.php?page=DCComics" class="bFoot">DC Comics</a></td>
        <td><a href="portfolio.php?page=LegoMovie" class="bFoot">Lego Movie</a></td>
        <td><a href="portfolio.php?page=Clone_Wars" class="bFoot">Clone_Wars</a></td>
        <td><a href="portfolio.php?page=LBM2" class="bFoot">LBM2</a></td>

    </tr>
</table>

<!-- Utilisation de la balise figure pour regrouper l'image et son commentaire -->
<figure style="float: left; margin-right: 20px;">
    <img src="image/Armoured_Dwarf_Guard.webp" alt="Description de l'image A-Bomb">
    <figcaption> Dwarf Guard</figcaption>
</figure>
<figure style="float: left;">
    <img src="image/Balin.webp" alt="Description de l'image Agent_Coulson">
    <figcaption> Balin </figcaption>
</figure>
<figure style="float: left;">
    <img src="image/Balin_(young).webp" alt="Description de l'image absorbing_man">
    <figcaption> Balin_(young) </figcaption>
</figure>
<figure style="float: left;">
    <img src="image/Balin.webp" alt="Description de l'image Agent_Coulson">
    <figcaption> Balin </figcaption>
</figure>
    <figure style="float: left;">
    <img src="image/Bifur.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Bifur </figcaption>
    </figure>
 <figure style="float: left;">
    <img src="image/Bilbo.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Bilbo </figcaption>
    </figure>
 <figure style="float: left;">
    <img src="image/Bilbo_Hobbiton.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Bilbo Hobbiton </figcaption>
    </figure>
 <figure style="float: left;">
    <img src="image/Bilbo_lake_town.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Bilbo(Laketown) </figcaption>
    </figure>



</body>
</html>
