<?php
// Redirige automatiquement vers LOTR.php
header("Location: portfolio.php?page=LOTR");
exit(); // Assure que le script s'arrête après la redirection
?>
