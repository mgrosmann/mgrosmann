<!-- test0.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test 0</title>
    <style>
        figure {
            display: inline-block;
            margin: 0;
        }

        figcaption {
            text-align: center;
        }
    </style>
</head>
<body>

<table id="Menu">
    <tr>
        <td><a href="portfolio.php?page=LOTR" class="bFoot">LOTR</a></td>
        <td><a href="portfolio.php?page=Hobbit" class="bFoot">Hobbit</a></td>
        <td><a href="portfolio.php?page=LSWCS" class="bFoot">LSWCS</a></td>
        <td><a href="portfolio.php?page=POTC" class="bFoot">POTC</a></td>
        <td><a href="portfolio.php?page=Marvel" class="bFoot">Marvel</a></td>
        <td><a href="portfolio.php?page=Harry_Potter" class="bFoot">Harry Potter</a></td>
        <td><a href="portfolio.php?page=DCComics" class="bFoot">DC Comics</a></td>
        <td><a href="portfolio.php?page=LegoMovie" class="bFoot">Lego Movie</a></td>
        <td><a href="portfolio.php?page=Clone_Wars" class="bFoot">Clone_Wars</a></td>
        <td><a href="portfolio.php?page=LBM2" class="bFoot">LBM2</a></td>


    </tr>
</table>

<!-- Utilisation de la balise figure pour regrouper l'image et son commentaire -->
<figure style="float: left;">
    <img src="image/Aberforth_Dumbledore.webp" alt="Description de l'image A-Bomb">
    <figcaption> Aberforth Dumbledore</figcaption>
</figure>
<figure style="float: left;">
    <img src="image/Albert_Runcorn.webp" alt="Description de l'image Abomination">
    <figcaption>Albert Runcorn </figcaption>
</figure>
<figure style="float: left;">
    <img src="image/Alecto_Carrow.webp" alt="Description de l'image absorbing_man">
    <figcaption> Alecto Carrow </figcaption>
</figure>
<figure style="float: left;">
    <img src="image/Amycus_Carrow.webp" alt="Description de l'image Agent_Coulson">
    <figcaption> Amycus Carrow </figcaption>
</figure>
    <figure style="float: left;">
    <img src="image/Anthony_Goldstein.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Anthony Goldstein </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Antonin_Dolohov.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Antonin Dolohov </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Argus_Filch.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Argus Filch</figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Bathilda.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Bathilda</figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Bellatrix_azkaban.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Bellatrix(azkaban)</figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Bellatrix_Lestrange.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Bellatrix Lestrange</figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Blaise_29_icon.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Blaise (black suit)</figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Blaise_Zabini_icon.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Blaise Zabini</figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Bloody_Baron.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Bloody Baron </figcaption>
    </figure>






</body>
</html>
