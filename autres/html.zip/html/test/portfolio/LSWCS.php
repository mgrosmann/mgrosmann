<!-- test0.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Test 0</title>
    <style>
        figure {
            display: inline-block;
            margin: 0;
        }

        figcaption {
            text-align: center;
        }
    </style>
</head>
<body>

<table id="Menu">
    <tr>
        <td><a href="portfolio.php?page=LOTR" class="bFoot">LOTR</a></td>
        <td><a href="portfolio.php?page=Hobbit" class="bFoot">Hobbit</a></td>
        <td><a href="portfolio.php?page=LSWCS" class="bFoot">LSWCS</a></td>
        <td><a href="portfolio.php?page=POTC" class="bFoot">POTC</a></td>
        <td><a href="portfolio.php?page=Marvel" class="bFoot">Marvel</a></td>
        <td><a href="portfolio.php?page=Harry_Potter" class="bFoot">Harry Potter</a></td>
        <td><a href="portfolio.php?page=DCComics" class="bFoot">DC Comics</a></td>
        <td><a href="portfolio.php?page=LegoMovie" class="bFoot">Lego Movie</a></td>
        <td><a href="portfolio.php?page=Clone_Wars" class="bFoot">Clone_Wars</a></td>
        <td><a href="portfolio.php?page=LBM2" class="bFoot">LBM2</a></td>


    </tr>
</table>

<!-- Utilisation de la balise figure pour regrouper l'image et son commentaire -->
<figure style="float: left; margin-right: 20px;">
     <img src="image/Aayla_Secura.webp" alt="Description de l'image Abomination">
    <figcaption>Aayla_Secura </figcaption>
</figure>
<figure style="float: left;">
   <img src="image/Admiral_Ackbar.webp" alt="Description de l'image absorbing_man">
    <figcaption> Admiral_Ackbar </figcaption>
</figure>
<figure style="float: left;">
    <img src="image/Anakin_Skywalker(boy).webp" alt="Description de l'image absorbing_man">
    <figcaption> Anakin Skywalker (boy) </figcaption>
</figure>
<figure style="float: left;">
    <img src="image/Anakin_Skywalker_(ghost).webp" alt="Description de l'image Agent_Coulson">
    <figcaption> Anakin Skywalker (ghost) </figcaption>
</figure>
    <figure style="float: left;">
    <img src="image/Anakin_Skywalker(jedi).webp" alt="Description de l'image Aim_Agent">
    <figcaption> Anakin Skywalker (jedi) </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Anakin_Skywalker_(padawan).webp" alt="Description de l'image Aim_Agent">
    <figcaption> Anakin Skywalker (padawan) </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Battle_Droid.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Battle Droid </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Battle_Droid_commander.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Battle Droid(commander) </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Battle_Droid_security.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Battle Droid(security) </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Battle_Droid_Geonosis.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Battle Droid Geonosis </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Beach_Trooper.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Beach Trooper </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Ben_Kenobi.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Ben Kenobi </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Ben_Kenobi_ghost.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Ben Kenobi (ghost) </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Bespin_Guard.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Garde Bespin </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Bib_Fortuna.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Bib Fortuna </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Boba_Fett.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Boba Fett </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Boba_Fett_young.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Boba fett (jeune) </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Bossk.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Bossk </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Boss_Nass.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Boss Nass </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/C3PO.webp" alt="Description de l'image Aim_Agent">
    <figcaption> C3PO </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Captain_Antilles.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Captain Antilles </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Captain_Panaka.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Captain Panaka </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Captain_Tarpals.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Captain Tarpals </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Chancellor_Palpatine.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Chancellor Palpatine </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Chewbacca.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Chewbacca </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Clone.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Clone </figcaption>
    </figure>

<figure style="float: left;">
    <img src="image/Clone_29.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Clone (episode III) </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Clone_Pilot29.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Clone Pilot (episode III) </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Clone_2C_Swamp.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Clone Swamp (episode III) </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Clone_2C_Walker.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Clone Walker (episode III) </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Commander_Cody.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Commander Cody </figcaption>
    </figure>
<figure style="float: left;">
    <img src="image/Count_Dooku.webp" alt="Description de l'image Aim_Agent">
    <figcaption> Count Dooku </figcaption>
    </figure>





</body>
</html>
