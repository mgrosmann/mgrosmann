<?php
// Inclure les fichiers de PHPMailer
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


 require 'C:\Users\PC\Documents\vault\Xampp\PHPMailer-master\src/Exception.php';
 require 'C:\Users\PC\Documents\vault\Xampp\PHPMailer-master\src/PHPMailer.php';
 require 'C:\Users\PC\Documents\vault\Xampp\PHPMailer-master\src/SMTP.php';

$mail = new PHPMailer(true);

try {
    // Configuration du serveur SMTP
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'qwafeurr@gmail.com'; // Remplacez par votre adresse Gmail
    $mail->Password   = 'lovepenis'; // Remplacez par votre mot de passe Gmail
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port       = 587;

    // Définir les destinataires
    $mail->setFrom('qwafeurr@gmail.com', 'Serveur web SIO');
    $mail->addAddress('grosmannmatheo@gmail.com'); // Le destinataire

    // Contenu de l'email
    $mail->isHTML(true);
    $mail->Subject = 'Rendez-vous';
    $mail->Body    = "
        <font face='arial'>
        Bonjour,<br><br>
        Prière de se retrouver sur Skype à <b>18h</b> aujourd'hui.<br>
        Merci et bonne journée.
        </font>
    ";

    // Envoyer l'email
    $mail->send();
    echo "Mail envoyé avec succès.";
} catch (Exception $e) {
    echo "Un problème est survenu. L'email n'a pas été envoyé. Mailer Error: {$mail->ErrorInfo}";
}
