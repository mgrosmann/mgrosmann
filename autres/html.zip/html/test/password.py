import random
import string
def generate_password(length):
    digits = string.digits
    lower_case = string.ascii_lowercase
    upper_case = string.ascii_uppercase
    symbols = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"
    all_characters = digits + lower_case + upper_case + symbols
    password_characters = random.sample(all_characters, len(all_characters))
    while len(password_characters) < length:
        next_char = random.choice(all_characters)
        if next_char not in password_characters[-2:]:
            password_characters.append(next_char)
    random.shuffle(password_characters)
    password = ''.join(password_characters[:length])
    return password
password = generate_password(100)
print(password)