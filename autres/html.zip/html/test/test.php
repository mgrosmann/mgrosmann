<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$output = shell_exec('python3 --version');
echo "<pre>$output</pre>";
?>
