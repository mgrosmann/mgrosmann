apt update && apt upgrade -y
apt install -y apache2
systemctl start apache2
apt install mysql-server -y
mysql_secure_installation
systemctl start mysql
apt install mariadb-server
cd /root
echo "python3 -m http.server 8000" > http8000.sh
chmod +x http8000.sh
ip addr flush dev enp0s3
