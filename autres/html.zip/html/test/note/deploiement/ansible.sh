#!/bin/bash

# Mettre à jour le système
sudo apt-get update && sudo apt-get upgrade -y

# Ajouter le dépôt Ansible et installer Ansible
sudo apt-add-repository --yes --update ppa:ansible/ansible
sudo apt-get install -y ansible

# Exemple de configuration Ansible
sudo bash -c 'cat <<EOT > /etc/ansible/hosts
[servers]
server1 ansible_host=192.168.1.10 ansible_user=ubuntu
server2 ansible_host=192.168.1.11 ansible_user=ubuntu
EOT'

echo "Ansible a été installé et configuré avec succès."
