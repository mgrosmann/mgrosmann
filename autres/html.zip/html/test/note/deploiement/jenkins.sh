#!/bin/bash

# Mettre à jour le système
sudo apt-get update && sudo apt-get upgrade -y

# Installer Java (nécessaire pour Jenkins)
sudo apt-get install -y openjdk-11-jdk

# Ajouter le dépôt Jenkins et installer Jenkins
wget -q -O - https://pkg.jenkins.io/debian/jenkins.io.key | sudo apt-key add -
sudo sh -c 'echo deb http://pkg.jenkins.io/debian-stable binary/ > /etc/apt/sources.list.d/jenkins.list'
sudo apt-get update
sudo apt-get install -y jenkins

# Démarrer et activer Jenkins
sudo systemctl start jenkins
sudo systemctl enable jenkins

echo "Jenkins a été installé et configuré avec succès."
