apt update && apt upgrade -y
apt install -y openssh-server
systemctl start ssh
apt install -y apache2
systemctl start apache2
apt install -y mysql-server
apt install -y mariadb-server
apt install -y john
cd /root
echo "nmap -p 80 192.168.1.0/24 -oG - | grep '/open' | awk '{print \$2,\$3}'" > scan.sh
chmod +x scan.sh
echo "python3 -m http.server 8000" > http8000.sh
chmod +x http8000.sh
scp -P 1622 mgrosmann@sio.jbdelasalle.com:/home/SIO/mgrosmann/script/docker.sh /root
chmod +x docker.sh
scp -P 1622 mgrosmann@sio.jbdelasalle.com:/home/SIO/mgrosmann/script/glpi.sh /root
chmod +x glpi.sh
scp -P 1622 mgrosmann@sio.jbdelasalle.com:/home/SIO/mgrosmann/script/promotheus.sh /root
chmod +x promotheus.sh
scp -P 1622 mgrosmann@sio.jbdelasalle.com:/home/SIO/mgrosmann/script/rsync.sh /root
chmod +x rsync.sh
scp -P 1622 mgrosmann@sio.jbdelasalle.com:/home/SIO/mgrosmann/script/test.sh /root
chmod +x test.sh
scp -P 1622 mgrosmann@sio.jbdelasalle.com:/home/SIO/mgrosmann/script/uninstall.sh /root
chmod +x uninstall.sh
ip addr flush dev enp0s3
echo "nameserver 192.168.1.1" > /etc/resolv.conf
passwd
adduser mgrosmann
usermod -aG sudo mgrosmann



_______________________________________



