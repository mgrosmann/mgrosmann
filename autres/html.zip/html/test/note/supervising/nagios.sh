#!/bin/bash

# Mettre à jour le système
sudo apt-get update && sudo apt-get upgrade -y

# Installer les dépendances nécessaires
sudo apt-get install -y apache2 php libapache2-mod-php php-gd libgd-dev build-essential unzip wget libssl-dev mailutils

# Télécharger et installer Nagios
wget https://assets.nagios.com/downloads/nagioscore/releases/nagios-4.5.7.tar.gz
tar -xvzf nagios-4.5.7.tar.gz
cd nagios-4.5.7
sudo ./configure --with-httpd-conf=/etc/apache2/sites-enabled
sudo make all
sudo make install-groups-users
sudo usermod -a -G nagios www-data
sudo make install
sudo make install-daemoninit
sudo make install-commandmode
sudo make install-config
sudo make install-webconf

# Configurer Apache
sudo a2enmod rewrite
sudo a2enmod cgi
sudo systemctl restart apache2
sudo htpasswd -c /usr/local/nagios/etc/htpasswd.users nagiosadmin

# Installer les plugins Nagios
cd ..
wget https://nagios-plugins.org/download/nagios-plugins-2.3.3.tar.gz
tar -xvzf nagios-plugins-2.3.3.tar.gz
cd nagios-plugins-2.3.3
sudo ./configure
sudo make
sudo make install

# Démarrer Nagios
sudo systemctl start nagios
sudo systemctl enable nagios

echo "Nagios a été installé et configuré avec succès."
