#!/bin/bash

# Mettre à jour le système
sudo apt-get update && sudo apt-get upgrade -y

# Ajouter le dépôt Grafana et installer Grafana
sudo apt-get install -y software-properties-common
sudo add-apt-repository "deb https://packages.grafana.com/oss/deb stable main"
wget -q -O - https://packages.grafana.com/gpg.key | sudo apt-key add -
sudo apt-get update
sudo apt-get install -y grafana

# Démarrer et activer Grafana
sudo systemctl start grafana-server
sudo systemctl enable grafana-server

echo "Grafana a été installé et configuré avec succès."
