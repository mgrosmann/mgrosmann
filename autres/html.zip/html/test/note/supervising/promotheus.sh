#!/bin/bash


echo "Mise à jour du système..."
sudo apt-get update && sudo apt-get upgrade -y

# Installer les dépendances nécessaires
echo "Installation des dépendances..."
sudo apt-get install -y apache2 php php-mysql libapache2-mod-php php-gd php-xml php-bcmath php-mbstring wget gnupg

# Ajouter le dépôt Zabbix et installer Zabbix
echo "Ajout du dépôt Zabbix..."
wget https://repo.zabbix.com/zabbix/7.0/ubuntu/pool/main/z/zabbix-release/zabbix-release_latest+ubuntu22.04_all.deb
sudo dpkg -i zabbix-release_latest+ubuntu22.04_all.deb
sudo apt-get update

echo "Installation de Zabbix..."
sudo apt-get install -y zabbix-server-mysql zabbix-frontend-php zabbix-agent

# Configurer la base de données pour Zabbix
echo "Configuration de la base de données pour Zabbix..."
sudo mysql -u root -p <<EOF
CREATE DATABASE zabbix CHARACTER SET utf8 COLLATE utf8_bin;
CREATE USER 'zabbix'@'localhost' IDENTIFIED BY 'root'; 
GRANT ALL PRIVILEGES ON zabbix.* TO 'zabbix'@'localhost';
FLUSH PRIVILEGES;
EXIT;
EOF

# Importer le schéma initial
echo "Importation du schéma de la base de données..."
zcat /usr/share/doc/zabbix-server-mysql*/create.sql.gz | sudo mysql -u zabbix -p zabbix

# Configurer Zabbix
echo "Configuration de Zabbix..."
sudo bash -c 'cat <<EOT > /etc/zabbix/zabbix_server.conf
DBHost=localhost
DBName=zabbix
DBUser=zabbix
DBPassword=root
EOT'
# Remplacez 'password' par le même mot de passe utilisé lors de la création de l'utilisateur MySQL

# Démarrer et activer Zabbix
echo "Démarrage et activation des services Zabbix..."
sudo systemctl restart zabbix-server zabbix-agent apache2
sudo systemctl enable zabbix-server zabbix-agent apache2

# Affichage du message de fin
echo "Zabbix a été installé et configuré avec succès."
echo "Accédez à l'interface Web de Zabbix via : http://<votre_ip>/zabbix"
