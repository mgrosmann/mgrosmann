// main.js

function calculateAverage() {
    const gradeContainers = document.querySelectorAll('.grade-container');
    let totalGrade = 0;
    let totalWeight = 0;

    gradeContainers.forEach(function (container) {
        const grades = container.querySelectorAll('.grade');
        const coefficients = container.querySelectorAll('.coefficient');

        for (let i = 0; i < grades.length; i++) {
            const gradeValue = parseFloat(grades[i].value);
            const coefficientValue = parseFloat(coefficients[i].value.replace(',', '.'));

            if (!isNaN(gradeValue) && !isNaN(coefficientValue)) {
                totalGrade += gradeValue * coefficientValue;
                totalWeight += coefficientValue;
            }
        }
    });

    const result = document.getElementById('result');
    if (totalWeight > 0) {
        const average = totalGrade / totalWeight;
        result.textContent = `Moyenne Générale : ${average.toFixed(2)}`;
    } else {
        result.textContent = 'Pas de données pour calculer la moyenne.';
    }
}

function addGrade(containerId) {
    const container = document.getElementById(containerId);
    const gradeInput = document.createElement('input');
    gradeInput.type = 'number';
    gradeInput.min = '0';
    gradeInput.max = '20';
    gradeInput.step = '0.1';
    gradeInput.classList.add('grade');

    const coefficientInput = document.createElement('input');
    coefficientInput.type = 'text';
    coefficientInput.value = '1';
    coefficientInput.classList.add('coefficient');

    container.appendChild(gradeInput);
    container.appendChild(document.createTextNode('Coefficient:'));
    container.appendChild(coefficientInput);
    container.appendChild(document.createElement('br'));
}

function calculateInformatiqueAverage() {
    const gradesContainerSLAM = document.getElementById('gradesContainer7');
    const gradesContainerSISR = document.getElementById('gradesContainer6');
    const coefficientSLAM = parseFloat(document.getElementById('coefficient7').value.replace(',', '.'));
    const coefficientSISR = parseFloat(document.getElementById('coefficient6').value.replace(',', '.'));

    let totalGradeSLAM = 0;
    let totalWeightSLAM = 0;
    let totalGradeSISR = 0;
    let totalWeightSISR = 0;

    const gradesSLAM = gradesContainerSLAM.querySelectorAll('.grade');
    for (let i = 0; i < gradesSLAM.length; i++) {
        const gradeValue = parseFloat(gradesSLAM[i].value);
        if (!isNaN(gradeValue)) {
            totalGradeSLAM += gradeValue;
            totalWeightSLAM += 1;
        }
    }

    const gradesSISR = gradesContainerSISR.querySelectorAll('.grade');
    for (let i = 0; i < gradesSISR.length; i++) {
        const gradeValue = parseFloat(gradesSISR[i].value);
        if (!isNaN(gradeValue)) {
            totalGradeSISR += gradeValue;
            totalWeightSISR += 1;
        }
    }

    const resultInformatique = document.getElementById('resultInformatique');
    if (totalWeightSLAM > 0 && totalWeightSISR > 0) {
        const averageSLAM = totalGradeSLAM / totalWeightSLAM;
        const averageSISR = totalGradeSISR / totalWeightSISR;
        const averageInformatique = (averageSLAM + averageSISR) / 2;
        resultInformatique.textContent = `Moyenne Informatique : ${averageInformatique.toFixed(2)}`;
    } else {
        resultInformatique.textContent = 'Pas de données pour calculer la moyenne Informatique.';
    }
}
