Import-Module ActiveDirectory
Import-Module GroupPolicy
netsh advfirewall firewall add rule name="Open Port 8530" dir=in action=allow protocol=TCP localport=8530
$DomainName = (Get-ADDomain).DNSRoot
$GPOName = "WSUS - Mises à jour automatique et Emplacement du service de mise à jour intranet"
New-GPO -Name $GPOName | Out-Null
$GPO = Get-GPO -Name $GPOName
Set-GPRegistryValue -Name $GPOName -Key "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate\AU" -ValueName "NoAutoUpdate" -Type DWord -Value 0
Set-GPRegistryValue -Name $GPOName -Key "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate\AU" -ValueName "AUOptions" -Type DWord -Value 3
$WSUSIntranetURL = "http://Your_WSUS_Server_FQDN:8530"
Set-GPRegistryValue -Name $GPOName -Key "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate" -ValueName "WUServer" -Type String -Value $WSUSIntranetURL
Set-GPRegistryValue -Name $GPOName -Key "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate" -ValueName "WUStatusServer" -Type String -Value $WSUSIntranetURL
Set-GPRegistryValue -Name $GPOName -Key "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate" -ValueName "TargetGroupEnabled" -Type DWord -Value 1
Set-GPRegistryValue -Name $GPOName -Key "HKLM\Software\Policies\Microsoft\Windows\WindowsUpdate" -ValueName "TargetGroup" -Type String -Value "Ring 4 Broad Business Users"
$WsusAdminCmd = "C:\Program Files\Update Services\Tools\wsusutil.exe"
if (Test-Path $WsusAdminCmd) {
    & $WsusAdminCmd usecustomwebsite true
    Write-Host "WSUS configuré pour le ciblage côté client."
} else {
    Write-Warning "L'utilitaire WSUS n'a pas été trouvé."
}
Function Add-WsusComputerGroup {
    param (
        [string]$GroupName
    )
    $WsusServer = Get-WsusServer
    $ExistingGroups = $WsusServer.GetComputerTargetGroups() | Where-Object { $_.Name -eq $GroupName }
    if (-not $ExistingGroups) {
        $WsusServer.CreateComputerTargetGroup($GroupName)
        Write-Host "Groupe WSUS créé : $GroupName"
    } else {
        Write-Host "Groupe WSUS déjà existant : $GroupName"
    }
}
Add-WsusComputerGroup -GroupName "Ring 2 Pilot Business Users"
Add-WsusComputerGroup -GroupName "Ring 3 Broad IT"
Add-WsusComputerGroup -GroupName "Ring 4 Broad Business Users"
Function Configure-WsusAutoApprovalRule {
    param (
        [string]$RuleName,
        [string]$GroupName,
        [int]$DeadlineDays
    )
    $WsusServer = Get-WsusServer
    $ApprovalRule = $WsusServer.GetAutomaticUpdateApprovalRules() | Where-Object { $_.Name -eq $RuleName }
    if (-not $ApprovalRule) {
        $ApprovalRule = $WsusServer.CreateAutomaticUpdateApprovalRule($RuleName)
        $ApprovalRule.SetComputerTargetGroupFilter($GroupName)
        $ApprovalRule.SetUpdateClassificationFilter([Microsoft.UpdateServices.Administration.UpdateClassification]::Upgrades)
        $ApprovalRule.SetUpdateProductFilter("Windows 10")
        $ApprovalRule.Deadline = (Get-Date).AddDays($DeadlineDays)
        $ApprovalRule.Save()
        Write-Host "Règle d'approbation automatique configurée : $RuleName"
    } else {
        Write-Host "Règle d'approbation automatique déjà existante : $RuleName"
    }
}

Configure-WsusAutoApprovalRule -RuleName "Windows 10 Upgrade Rule" -GroupName "Ring 3 Broad IT" -DeadlineDays 7