# Pokemon-like-Game-Made-in-Kaboom.js

Final source code for making a Pokemon-like game using the Kaboom.js library.

Watch the tutorial if you want to learn how to build this : https://youtu.be/zo3crHnFGho

Demo link : https://jslegend.itch.io/pokemon-like-tutorial-kaboomjs
