document.addEventListener('DOMContentLoaded', () => {
    const board = document.getElementById('tetris-board');
    const cellSize = 30;
    const rows = 20;
    const cols = 10;
    let score = 0;
    let gameStarted = false;
    let gameInterval;
  
    const shapes = [
      { class: 'shape1', coordinates: [[0, 0], [1, 0], [1, 1], [2, 1]] },
      { class: 'shape2', coordinates: [[0, 1], [1, 1], [2, 1], [2, 0]] },
      { class: 'shape3', coordinates: [[0, 1], [1, 1], [2, 1], [2, 2]] },
      // Add more shapes as needed
    ];
  
    let currentShape;
  
    function createShape() {
      const randomIndex = Math.floor(Math.random() * shapes.length);
      const shape = shapes[randomIndex];
      currentShape = shape;
      drawShape();
    }
  
    function drawShape() {
      currentShape.element = document.createElement('div');
      currentShape.element.classList.add('shape', currentShape.class);
  
      currentShape.coordinates.forEach(coord => {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        cell.style.top = `${coord[0] * cellSize}px`;
        cell.style.left = `${coord[1] * cellSize}px`;
        currentShape.element.appendChild(cell);
      });
  
      board.appendChild(currentShape.element);
    }
  
    function moveDown() {
      const canMove = currentShape.coordinates.every(coord => coord[0] < rows - 1);
      if (canMove) {
        currentShape.coordinates.forEach(coord => coord[0]++);
        updateShapePosition();
      } else {
        freezeShape();
        clearLines();
        createShape();
      }
    }
  
    function moveLeft() {
      const canMove = currentShape.coordinates.every(coord => coord[1] > 0);
      if (canMove) {
        currentShape.coordinates.forEach(coord => coord[1]--);
        updateShapePosition();
      }
    }
  
    function moveRight() {
      const canMove = currentShape.coordinates.every(coord => coord[1] < cols - 1);
      if (canMove) {
        currentShape.coordinates.forEach(coord => coord[1]++);
        updateShapePosition();
      }
    }
  
    function rotate() {
      // Implement rotation logic here
    }
  
    function updateShapePosition() {
      currentShape.coordinates.forEach((coord, index) => {
        const cell = currentShape.element.children[index];
        cell.style.top = `${coord[0] * cellSize}px`;
        cell.style.left = `${coord[1] * cellSize}px`;
      });
    }
  
    function freezeShape() {
      currentShape.coordinates.forEach(coord => {
        const row = coord[0];
        const col = coord[1];
        const cell = document.createElement('div');
        cell.classList.add('cell', currentShape.class);
        cell.style.top = `${row * cellSize}px`;
        cell.style.left = `${col * cellSize}px`;
        board.appendChild(cell);
      });
  
      board.removeChild(currentShape.element);
    }
  
    function clearLines() {
      for (let row = rows - 1; row >= 0; row--) {
        const cells = document.querySelectorAll(`.cell:nth-child(${row * cols + 1})`);
        if (cells.length === cols) {
          cells.forEach(cell => board.removeChild(cell));
          score += 100;
          document.getElementById('score').innerText = `Score: ${score}`;
          moveLinesDown(row);
        }
      }
    }
  
    function moveLinesDown(clearedRow) {
      for (let row = clearedRow - 1; row >= 0; row--) {
        const cells = document.querySelectorAll(`.cell:nth-child(${row * cols + 1})`);
        cells.forEach(cell => {
          const top = parseInt(cell.style.top, 10) + cellSize;
          cell.style.top = `${top}px`;
        });
      }
    }
  
    function drop() {
      while (canMoveDown()) {
        moveDown();
      }
    }
  
    function canMoveDown() {
      return currentShape.coordinates.every(coord => coord[0] < rows - 1);
    }
  
    function startGame() {
      gameInterval = setInterval(moveDown, 500); // Adjust the speed as needed
    }
  
    document.addEventListener('keydown', (event) => {
      if (!gameStarted && event.key === ' ') {
        startGame();
        gameStarted = true;
      } else {
        switch (event.key) {
          case 'ArrowLeft':
            moveLeft();
            break;
          case 'ArrowRight':
            moveRight();
            break;
          case 'ArrowDown':
            moveDown();
            break;
          case 'ArrowUp':
            rotate();
            break;
          case 'a':
            drop();
            break;
        }
      }
    });
  });
  