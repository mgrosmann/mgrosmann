<?php
  header('Location: https://www.numworks.com/fr/simulateur/');
  exit();
?>