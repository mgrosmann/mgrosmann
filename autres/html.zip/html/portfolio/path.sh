#!/bin/bash
echo "export PATH=$PATH:/root/bin" >> /root/.bashrc
source .bashrc
