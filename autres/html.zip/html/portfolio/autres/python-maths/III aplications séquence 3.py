salaire = 20000
annee=2016
print ("En 2016, le salaire perçu est (en euros ): 2000")
while salaire < 25000:
    salaire = salaire *1.02
    annee = annee + 1
    print("En ",annee, " le salaire perçu est (en euros) :" ,round(salaire,2))

          
    
