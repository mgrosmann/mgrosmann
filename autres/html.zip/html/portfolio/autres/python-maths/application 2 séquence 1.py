a=int(input("saisir a"))
b=int(input("saisir b"))
if a==b:
    print("ils sont égaux")
elif a>b:
    print ("la plus grande valeur est ",a)
else:
    print ("la plus grande valeur est ",b)
