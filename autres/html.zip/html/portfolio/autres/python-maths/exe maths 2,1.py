a=int(input("Enter a number"))
b=int(input("Enter a number"))
c= a+b
4
5
5
5
4
