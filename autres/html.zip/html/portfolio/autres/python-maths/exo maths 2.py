n=int(input("Enter a number:"))
a=n-4
res=a*n
res=res+4
print(res)
