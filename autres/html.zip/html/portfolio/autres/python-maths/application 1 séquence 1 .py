nb=int(input("saisir un entier : "))
print(nb)