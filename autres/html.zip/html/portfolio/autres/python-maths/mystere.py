def mystere (nb):
    somme=0
    for i in range(0,nb):
        somme=somme+i
    return somme

print(mystere(5))
