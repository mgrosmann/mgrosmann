def affichage(L):

    for i in range(len(L)):
        print(L[i])

liste=[10,4,5,78,13]
affichage(liste)
