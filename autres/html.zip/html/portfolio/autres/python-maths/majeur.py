
age=int(input("Quel est votre age ?"))
if (age<18):
        print("mineur")
else:
    print("majeur")
    
