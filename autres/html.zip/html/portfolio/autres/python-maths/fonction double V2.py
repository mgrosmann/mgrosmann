#Définitions des pratiques anticoncurrentielles

#Les pratiques anticoncurrentielles désignent trois types de pratiques
#commerciales contraires au droit de la concurrence:
#-les ententes illicites,
#-les abus de dominatiion ou abus de poistion dominante
#-et les offres et pratiques de prix abusivement basestring

#Entente illicite(aussi nommé cartel)On parle d'entente illlicite lorsque l'accord empêche, restreint, ou fausse 
#le jeu normal de la concurrence. En france, la sanction pour El est plafonnée à 10%
#du chiffre d'affaire mondiol hors taxe.
#L'abus de postion dominante consiste, pour une entreprise présnete sur un marché, ou un groupe 
#d'entreprise à adpoter un comportement visant à éléminer, à contraindre.dissuader tout 
#tout concurrent d'entrer se maintenir sur ce marché ou un marché connexe, faussant insi la concurrence. Il 
#consiste donc à evincer les concurrents potnetiels ou obtenir des avanatages au détriments des consommateurs