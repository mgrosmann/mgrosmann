#!/bin/bash
apt install sl cowsay fortune figlet toilet cmatrix lolcat neofetch ponysay bb asciiquarium -y
