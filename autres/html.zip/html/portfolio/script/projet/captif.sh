#!/bin/bash
curl --request POST --data "user=tbm&cmd=authenticate&password=P@ssw0rd" 'http://192.168.1.1:8002/index.php?zone=portail'
