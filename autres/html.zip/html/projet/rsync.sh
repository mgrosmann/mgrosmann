#!/bin/bash
echo "Installation de rsync..."
sudo apt update
sudo apt install -y rsync
mkdir /home/mgrosmann/backup
mkdir /home/mgrosmann/desktop
mkdir /home/mgrosmann/save
chmod +x save.sh
chmod +x backup.sh
echo "installation finalisée, n'oubliez pas de modifier les fichiers save.sh et backup.sh afin de définir l'adresse ip et le user de la machine distante qui servira a stocker les sauvegarde et les restaurer"
