#!/bin/bash
apt update
apt-get install -y apache2 mariadb-server
mysql_secure_installation <<EOF
y
n
y
y
y
y
EOF
mysql  <<EOF
ALTER USER 'root'@'localhost' IDENTIFIED BY 'root';
CREATE DATABASE glpi;
CREATE USER 'glpi'@'localhost' IDENTIFIED BY 'glpi';
GRANT ALL PRIVILEGES ON glpi.* TO 'glpi'@'localhost';
FLUSH PRIVILEGES;
EOF
