<nav>
    <ul>
        <li><a href="?page=exemples">Exemples</a></li>
        <li><a href="?page=joueurs">Joueurs</a></li>
        <li><a href="?page=entrainements">Entrainements</a></li>
        <li><a href="?page=matchs">Matchs</a></li>
    </ul>
</nav>