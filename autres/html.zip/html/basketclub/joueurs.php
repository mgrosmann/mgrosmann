<h1>Joueurs (Anthony Médassi)</h1>
<div id="div_joueurs">
    <style>
<?php include "styles/joueurs.css"; ?>
    </style>
</div>